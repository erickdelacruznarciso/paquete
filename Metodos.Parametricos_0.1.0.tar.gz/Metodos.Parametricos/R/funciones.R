pzi=function(x,mu,s,n,cola.izquierda=T){(z=(x-mu)/(s/sqrt(n)));
  pnorm(z,cola.izquierda)}

pzf=function(x,mu,s,n,N,cola.izquierda=T){z=(x-mu)/
  ((s/sqrt(n))*sqrt((N-n)/(N-1)));
pnorm(z,0,1,cola.izquierda)}

pti=function(x,mu,s,n,cola.izquierda=T){t=(x-mu)/((s/sqrt(n)));
pt(t,n-1,cola.izquierda)}

ptf=function(x,mu,s,n,N,cola.izquierda=T){t=(x-mu)/((s/
sqrt(n))*sqrt((N-n)/(N-1)));
pt(t,n-1,cola.izquierda)}

pchi2=function(s,sigma,n,cola.izquierda=T){x2=(s^2*(n-1))/sigma^2;
pchisq(x2,n-1,cola.izquierda)}

pzi2=function(difmayor,difmenor,s1,s2,n1,n2,cola.izquierda=T)
{z=(difmayor-difmenor)/sqrt((s1^2/n1)+(s2^2/n2));
(pnorm(z,cola.izquierda))}

pzf2=function(difmayor,difmenor,s1,s2,n1,n2,N1,N2,
cola.izquierda=T){z=(difmayor-difmenor)/sqrt((s1^2/n1)*
((N1-n1)/(N1-1))+(s2^2/n2)*((N2-n2)/(N2-1)));
pnorm(z,cola.izquierda)}

ptvar.dist=function(difmayor,difmenor,s1,s2,n1,n2,cola.izquierda=T)
{t=(difmayor-difmenor)/sqrt((s1^2/n1)+(s2^2/n2));
(pt(t,n1+n2-2,cola.izquierda))}

ptvar.iguales=function(difmayor,difmenor,s1,s2,n1,n2,cola.izquierda=T)
{t=(difmayor-difmenor)/sqrt((1/n1)+(1/n2))*
  sqrt((s1^2*(n1-1)+(s2^2*(n2-2)))/(n1+n2-2));
pt(t,n1+n2-2,cola.izquierda)}
